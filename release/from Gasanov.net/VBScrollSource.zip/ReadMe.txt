Overview
--------
VBScroll solves the problem with mouse wheel scrolling in Visual Basic IDE
and VBA editor in Microsoft Office applications such as Word, Excel and etc.
Microsoft IntelliPoint 4.12 (not newer versions) mouse driver does the same,
but in some situations it's impossible to install or use it. For example,
if you are running Windows Server 2003 or working on laptop with touchpad.
Besides this VBScroll enhances wheel functionality in listed evironment.

Disclaimer
----------
This program is provided AS IS without warranty of any kind
and author will not be liable for any damage caused by it.

Installation
------------
Unpack downloaded ZIP-file to any directory and run VBScroll.exe.
To configure right click on its tray icon and choose appropriate menu.

Removing
--------
Open the configure dialog select "Manual" in "Startup" options and press "OK".
This will delete shortcut from "Startup" folder (you can do it yourself).
Exit program and delete all files from VBScrol package.

Contact
-------
www.gasanov.net
shahin@gasanov.net
